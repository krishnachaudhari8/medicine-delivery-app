package com.example.medicinedeliveryapp;

import static com.example.medicinedeliveryapp.R.*;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class page1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page1);

        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Thread t = new Thread() {
            @Override
            public void run() {
                try {

                    sleep(2000);
                    Intent i = new Intent(page1.this, page2.class);
                    startActivity(i);
                    finish();

                }
                catch(Exception e)
                {
                    System.out.println("error=" + e);
                }
                super.run();
            }
        };
        t.start();
    }
}