package com.example.medicinedeliveryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class page6 extends AppCompatActivity {

    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page6);
        Button btn1=findViewById(R.id.btn1);
        EditText no1=findViewById(R.id.no1);
        EditText no2=findViewById(R.id.no2);
        EditText no3=findViewById(R.id.no3);
        ref= FirebaseDatabase.getInstance().getReference().child("user");
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = no1.getText().toString();
                String address = no2.getText().toString();
                String mobile = no3.getText().toString();


                info i1= new info(name,address,mobile);
                ref.child(address).setValue(name);
                ref.child(name).setValue(mobile);
                Intent i = new Intent(page6.this, feedbackform.class);
                startActivity(i);
            }
        });

    }
}