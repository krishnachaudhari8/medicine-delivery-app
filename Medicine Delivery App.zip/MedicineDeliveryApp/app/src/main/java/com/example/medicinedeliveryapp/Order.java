package com.example.medicinedeliveryapp;

public class Order {

    String order;

    public Order(String order) {
        this.order = order;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }
}
