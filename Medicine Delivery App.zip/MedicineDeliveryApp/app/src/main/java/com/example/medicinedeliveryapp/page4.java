package com.example.medicinedeliveryapp;

import android.content.Intent;
import android.view.View;
import android.widget.Button;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class page4 extends AppCompatActivity {
DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page4);
        Button btn1=findViewById(R.id.btn1);
        EditText no1=findViewById(R.id.no1);
        EditText no2=findViewById(R.id.no2);
        ref= FirebaseDatabase.getInstance().getReference().child("user");
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String m = no1.getText().toString();
                String c = no1.getText().toString();

                medicine u1= new medicine(m,c);
                ref.child(c).setValue(c);
                Intent i = new Intent(page4.this, page5.class);
                startActivity(i);
                i.putExtra("medicine","m"+m);
            }

        });
    }
}