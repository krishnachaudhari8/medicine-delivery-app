package com.example.medicinedeliveryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class homepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.user, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.page2) {
            Intent i=new Intent(homepage.this,page2.class);
            startActivity(i);
        } else if (id == R.id.page3) {
            Intent i=new Intent(homepage.this,page3.class);
            startActivity(i);
        } else if (id == R.id.page4) {
            Intent i=new Intent(homepage.this,page4.class);
            startActivity(i);
        }
        else if (id == R.id.page5) {
            Intent i=new Intent(homepage.this,page5.class);
            startActivity(i);
        }
        else if (id == R.id.page6) {
            Intent i=new Intent(homepage.this,page6.class);
            startActivity(i);
        }
        else if (id == R.id.feedbackform) {
            Intent i=new Intent(homepage.this,feedbackform.class);
            startActivity(i);
        }

        return super.onOptionsItemSelected(item);
    }
}