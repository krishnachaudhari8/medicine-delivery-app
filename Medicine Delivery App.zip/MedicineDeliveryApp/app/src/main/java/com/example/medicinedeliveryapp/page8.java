package com.example.medicinedeliveryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class page8 extends AppCompatActivity {
        DatabaseReference ref;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_page8);
            Button btn1=findViewById(R.id.btn1);
            EditText no1=findViewById(R.id.no1);

            ref= FirebaseDatabase.getInstance().getReference().child("admin");
            btn1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String order = no1.getText().toString();



                    Order o1= new Order(order);
                    ref.child(order).setValue(order);
                Intent i = new Intent(page8.this, page9.class);
                startActivity(i);
            }

        });
    }
}