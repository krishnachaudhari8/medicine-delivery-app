package com.example.medicinedeliveryapp;

public class medicine {
    String m,c;

    public medicine(String m, String c) {
        this.m = m;
        this.c = c;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }

    public String getC() {
        return c;
    }

    public void setC(String c) {
        this.c = c;
    }
}
