package com.example.medicinedeliveryapp;
public class user {
    String u, m, p;

    public user(String u, String m, String p) {
        this.u = u;
        this.m = m;
        this.p = p;
    }

    public String getU() {
        return u;
    }

    public void setU(String u) {
        this.u = u;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }

    public String getP() {
        return p;
    }

    public void setP(String p) {
        this.p = p;
    }
}
