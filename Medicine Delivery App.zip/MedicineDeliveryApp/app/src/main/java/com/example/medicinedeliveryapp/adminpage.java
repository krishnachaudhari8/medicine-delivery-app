package com.example.medicinedeliveryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class adminpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminpage);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.admin, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();


        if (id == R.id.page7) {
            Intent i=new Intent(adminpage.this,page7.class);
            startActivity(i);
        } else if (id == R.id.page8) {
            Intent i=new Intent(adminpage.this,page8.class);
            startActivity(i);
        } else if (id == R.id.page9) {
            Intent i=new Intent(adminpage.this,page9.class);
            startActivity(i);
        }
        else if (id == R.id.page10) {
            Intent i=new Intent(adminpage.this, page10.class);
            startActivity(i);
        }
        else if (id == R.id.sendsms) {
            Intent i=new Intent(adminpage.this,sendsms.class);
            startActivity(i);
        }

        return super.onOptionsItemSelected(item);
    }
}