package com.example.medicinedeliveryapp;

public class MedicineDetails {
 String m;

    public MedicineDetails(String m) {
        this.m = m;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }
}
