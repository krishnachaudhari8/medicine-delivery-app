package com.example.medicinedeliveryapp;


import static android.app.ProgressDialog.show;

import static com.example.medicinedeliveryapp.R.id.no2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class page3 extends AppCompatActivity {
    DatabaseReference ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // EdgeToEdge.enable(this);
        setContentView(R.layout.activity_page3);
        EditText username=findViewById(R.id.username);
        EditText password=findViewById(R.id.password);

        Button btn1=findViewById(R.id.btn1);
        ref = FirebaseDatabase.getInstance().getReference().child("register");
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String u = username.getText().toString();
                String p = password.getText().toString();
                if (username.getText().toString().equals("" + u) && password.getText().toString().equals("" + p)) {
                    Toast.makeText(page3.this, "Login", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(page3.this, homepage.class);
                    startActivity(i);
                } else {
                    Toast.makeText(page3.this, "Login fail", Toast.LENGTH_SHORT).show();
                }

            }

        });

    }

}