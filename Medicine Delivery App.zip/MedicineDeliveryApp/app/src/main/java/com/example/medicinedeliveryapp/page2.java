package com.example.medicinedeliveryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.medicinedeliveryapp.R;
import com.google.firebase.Firebase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class page2 extends AppCompatActivity {
    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);
        Button btn=findViewById(R.id.btn);
        Button btn1=findViewById(R.id.btn1);
        EditText n1=findViewById(R.id.n1);
        EditText n2=findViewById(R.id.n2);
        EditText n3=findViewById(R.id.n3);
        ref=FirebaseDatabase.getInstance().getReference().child("user");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(page2.this, page7.class);
                startActivity(i);
                String u = n1.getText().toString();
                String m=  n2.getText().toString();
                String p=  n3.getText().toString();

                user u1= new user(u,m,p);
                ref.child(u).setValue(m);
                Toast.makeText(page2.this, "Store", Toast.LENGTH_SHORT).show();
            }

        });
        ref=FirebaseDatabase.getInstance().getReference().child("user");
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(page2.this, page3.class);
                startActivity(i);
                String u = n1.getText().toString();
                String m=  n2.getText().toString();
                String p=  n3.getText().toString();

                user u1= new user(u,m,p);
                ref.child(u).setValue(m);
                Toast.makeText(page2.this, "Store", Toast.LENGTH_SHORT).show();
            }


        });

    }
}