package com.example.medicinedeliveryapp;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class page5 extends AppCompatActivity {
DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_page5);
        Button btn1=findViewById(R.id.btn1);
        EditText no1=findViewById(R.id.no1);
        ref= FirebaseDatabase.getInstance().getReference().child("user");
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String m = no1.getText().toString();

                MedicineDetails m1= new MedicineDetails(m);
                ref.child(m).setValue(m);
                Intent i = new Intent(page5.this, page6.class);
                startActivity(i);
                i.putExtra("Medicine Details","m"+m);
            }

        });
    }
}