package com.example.medicinedeliveryapp;

public class Dispatch {
    String d;

    public Dispatch(String d) {
        this.d = d;
    }

    public String getD() {
        return d;
    }

    public void setD(String d) {
        this.d = d;
    }
}
